using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aspnetcoreapp.Pages;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {

    } 
    public void OnPost()
{
    if (Request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
    {
        string num1Str = Request.Form["num1"];
        string num2Str = Request.Form["num2"];

        // Check which operation button was clicked and perform the respective calculation
        if (Request.Form["ADD"] == "ADD")
        {
            if (double.TryParse(num1Str, out double num1) && double.TryParse(num2Str, out double num2))
            {
                ViewData["result"] = num1 + num2;
            }
            else
            {
                ViewData["error"] = "Please enter valid numbers for addition.";
            }
        }
        else if (Request.Form["SUBTRACT"] == "SUBTRACT")
        {
            if (double.TryParse(num1Str, out double num1) && double.TryParse(num2Str, out double num2))
            {
                ViewData["result"] = num1 - num2;
            }
            else
            {
                ViewData["error"] = "Please enter valid numbers for subtraction.";
            }
        }
        else if (Request.Form["MULTIPLY"] == "MULTIPLY")
        {
            if (double.TryParse(num1Str, out double num1) && double.TryParse(num2Str, out double num2))
            {
                ViewData["result"] = num1 * num2;
            }
            else
            {
                ViewData["error"] = "Please enter valid numbers for multiplication.";
            }
        }
        else if (Request.Form["SQUARE"] == "SQUARE")
        {
            if (double.TryParse(num1Str, out double num1))
            {
                ViewData["result"] = num1 * num1;
            }
            else
            {
                ViewData["error"] = "Please enter a valid number to square.";
            }
        }
        else if (Request.Form["CUBE"] == "CUBE")
        {
            if (double.TryParse(num1Str, out double num1))
            {
                ViewData["result"] = num1 * num1 * num1;
            }
            else
            {
                ViewData["error"] = "Please enter a valid number to cube.";
            }
        }
    }
}
}
        