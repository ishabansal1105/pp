﻿// Tail recursive function to find the product of all elements in a list
let rec productTailRec list acc =
    match list with
    | [] -> acc  // Base case: when the list is empty, return the accumulator
    | head :: tail -> productTailRec tail (acc * head)  // Recursive call with the new accumulator

// Usage example
let numbers = [1; 2; 3; 4; 5]
let result = productTailRec numbers 1  // Start with an initial accumulator value of 1
printfn "Product of all elements: %d" result

//second
// Tail recursive function to calculate the product of all odd numbers from n to 1
let rec productOddNumbers n acc =
    if n < 1 then acc  // Base case: if n is less than 1, return the accumulator
    else productOddNumbers (n - 2) (acc * n)  // Recursive call, decrement by 2 for odd numbers

// Usage example
let n = 11
let result1 = productOddNumbers n 1  // Start with an accumulator value of 1
printfn "Product of all odd numbers from %d to 1: %d" n result

//third
// List of strings with extra spaces
let names: string list = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]

// Use List.map to trim spaces from the list of strings
let trimmedNames: string list = List.map (fun (name: string) -> name.Trim()) names

// Print the results
trimmedNames |> List.iter (printfn "%s")

//fourth
// Create a sequence of integers from 1 to 700
let numbers1 = Seq.init 700 (fun i -> i + 1)

// Filter out multiples of both 7 and 5
let filteredNumbers = numbers |> Seq.filter (fun x -> x % 7 = 0 && x % 5 = 0)

// Sum the filtered numbers using fold
let sum = filteredNumbers |> Seq.fold (+) 0

// Display the result
printfn "Sum of numbers that are multiples of both 7 and 5: %d" sum

//fifth
let names5: string list = ["Isha"; "Sid"; "Kashish"; "Rawmeen"; "Roban"; "Rohit"; "Arjun"]
let filteredNames = 
    List.filter (fun (name: string) -> name.Contains("I") || name.Contains("i")) names5
let concatenatedNames = 
    match filteredNames with
    | [] -> "" // Handle empty case
    | _ -> List.reduce (fun acc name -> acc + name) filteredNames
printfn "Concatenated names: %s" concatenatedNames